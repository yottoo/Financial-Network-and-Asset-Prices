from urllib.request import urlopen
from urllib.request import Request
from urllib import parse
from bs4 import BeautifulSoup
import re
import pymysql.cursors
import requests
import time
import json
import codecs
from decimal import getcontext, Decimal 
import math
import csv
import pandas as pd
import sys
import xlrd
import xlutils.copy

def read_excel(path):
	wb = xlrd.open_workbook(path)
	sheet = wb.sheets()[0]
	n = 0
	while n < sheet.nrows:
		print(sheet.nrows)
		print(sheet.row(n))
		n+=1

def write_excel(write_path,content):

	try:
		with open(write_path,'a') as w:
			w.write(str(content)+'\n')
	except:
		print('fail')


	# book = xlrd.open_workbook(write_path)
	# wtbook = xlutils.copy.copy(book)
	# wtsheet = wtbook.get_sheet(0)
	# row = wtsheet.nrows
	# wtsheet.write(row,content)

	# wtbook.save(write_path)





read_name = '2017-2-s' 
read_path = 'C:\\Users\\zhiha\\Desktop\\same\\'+read_name+'.xlsx'
write_name = 'same'
write_path = 'C:\\Users\\zhiha\Desktop\\total_ab\\'+write_name+'.txt'



wb = xlrd.open_workbook(read_path)
sheet = wb.sheets()[0]
n = 0
while n < sheet.nrows:
	print(sheet.nrows)
	print(sheet.row(n))
	col = sheet.ncols
	c = 0
	content = ''
	while c < col:
		cell = sheet.cell_value(n,c)
		content += str(cell)+','
		c+=1
	write_excel(write_path,content)
	n+=1


#read_excel(path)