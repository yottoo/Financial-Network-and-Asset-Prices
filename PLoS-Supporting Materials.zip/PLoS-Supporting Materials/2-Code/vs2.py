from urllib.request import urlopen
from urllib.request import Request
from urllib import parse
from bs4 import BeautifulSoup
import re
import pymysql.cursors
import requests
import time
import json
import codecs
from decimal import getcontext, Decimal 
import math
import csv
import pandas as pd

#mvfile_num = 5
def mv_value(num_1,num_2,date):
	value_1 = ''
	value_2 = ''
	count = 0
	for mvfile_num in range(1,6):
		mvfile_path = 'C:\\Users\\zhiha\\Desktop\\market_value\\'+str(mvfile_num)+'.csv'
		df = pd.read_csv(mvfile_path,encoding='utf-8',header=0)
		print(df.head(5))
		
		#df.loc[((df['Stknm']== name_2)&(df['Date']==re.compile(date))),'Montmv']
		#&(df['Date']==re.compile(date))
		#findnum_1 = df.loc[((df['Stknm']== name_1)),'Stkcd']
		#findnum_2 = df.loc[((df['Stknm']== name_2)),'Stkcd']
		result_1 = df.loc[((df['Stkcd']== num_1)&(df['Date'].isin([date+'29',date+'30',date+'31']))),'Montmv']
		result_2 = df.loc[((df['Stkcd']== num_2)&(df['Date'].isin([date+'29',date+'30',date+'31']))),'Montmv']
		if not result_1.empty:
			value_1 = result_1.values[0]
			count += 1
			print(mvfile_path)
			print('1:'+str(value_1))

		if not result_2.empty:
			value_2 = result_2.values[0]
			count += 1
			print(mvfile_path)
			print('2:'+str(value_2))
		if count >= 2:
			break

	if value_1 == '' or value_2 == '':
		return 1
	else:
		return float(value_1)*float(value_2)

if __name__ == '__main__':
	name_1 = "平安银行"
	name_2 = "华宇软件"
	date = '2012/9/'
	filename = '2012-3'
	wrong_stock_value = []
	numfile_path = 'C:\\Users\\zhiha\\Desktop\\top10_stock.csv'
	df = pd.read_csv(numfile_path,encoding='utf-8',header=0)
	num_1 = df.loc[((df['Stknm']== name_1)),'Stkcd'].values[0]
	num_2 = df.loc[((df['Stknm']== name_2)),'Stkcd'].values[0]
	print(name_1+name_2+date)
	print(str(num_1))
	print(str(num_2))

	value = mv_value(num_1,num_2,date)
	print(value)
	if value == 1 :
		wrong_stock_value.append(str(num_1)+','+str(num_2))
		print('最终结果'+str(0))
	else :
		print('最终结果'+str(value))
	print(wrong_stock_value)
	stock_strength = {'1':value,'2':value}


	# try:
	# 	writepath = 'C:\\Users\\zhiha\\Desktop\\weighted_net\\'+filename+'.txt'
	# 	for values in stock_strength.values():
	# 		print(values)
	# 		with open(writepath,'a') as w:
	# 			w.write(str(values)+'\n')
	# except:
	# 	print('fail')