from urllib.request import urlopen
from urllib.request import Request
from urllib import parse
from bs4 import BeautifulSoup
import re
import pymysql.cursors
import requests
import time
import json
import codecs
from decimal import getcontext, Decimal 
import math
import csv
import pandas as pd

#数据库连接用
connection = pymysql.connect(
	host = 'localhost',
	user = 'root',
	password = 'java',
	db = 'funds_info',
	charset = 'utf8mb4'
	)


def read_csv(mvfile_path):
	df = pd.read_csv(mvfile_path,encoding='utf-8',header=0)
	return df
	

date = '2012/3/'
filename = '2012-1'
filepath = 'C:\\Users\\zhiha\\Desktop\\20171117\\'+filename+'.net'
n = 0

name_col = 0
stock_name = {}
stock_strength = {}
with codecs.open(filepath,'r','utf-8') as f:
	while True:
		line = f.readline()
		if not line:
			break
		n += 1
		if n==1:
			name_col = line.split(' ')[-1]
			#print(name_col)
		elif n <= int(name_col)+1:
			number = line.split(' ')[0]
			name = line.split(' ')[-1].strip()
			stock_name.update({number:name})
			stock_strength.update({number:0})
			#print(stock_strength)
			#print(stock_name)
		elif n > int(name_col)+2:

			stock_1 = line.split(' ')[0]
			stock_2 = line.split(' ')[1]
			name_1 = stock_name.get(stock_1)
			name_2 = stock_name.get(stock_2)
			mvalue_1 = ''
			mvalue_2 = ''

			
			finished_mv = 0
			for mvfile_num in range(1,6):
				mvfile_path = 'C:\\Users\\zhiha\\Desktop\\market_value\\'+str(mvfile_num)+'.csv'
				print(mvfile_path)
				df = read_csv(mvfile_path)
				col = df[df['Stknm']== name_1]
				if col is None:
					continue
				else:
					print(col)
					break




				with codecs.open(mvfile_path,'r') as csvfile:
					reader = csv.DictReader(csvfile)
					rows = [row for row in reader]
					#print(rows)s
					for row in rows:
						for key in row.keys():
							print(key+'\n')
						print(row.keys())
						print(row.values())
						print(row['Stkcd'])
						if row.get('Stknm')== name_1 and row.get('Date')==re.compile(date):
							mvalue_1 = row['Montmv']
							finished_mv += 1
						elif row.get('Stknm') == name_2 and row.get('Date')==re.compile(date):
							mvalue_2 = row['Montmv']
							finished_mv += 1
						elif finished_mv >= 2:
							break
						else:
							continue
		

		mvalue_1 = ''
			mvalue_2 = ''

			
			finished_mv = 0
			for mvfile_num in range(1,6):

				mvfile_path = 'C:\\Users\\zhiha\\Desktop\\market_value\\'+str(mvfile_num)+'.csv'
				print(mvfile_path)
				df = read_csv(mvfile_path)
				#print(df.head(5))
				print(name_1 + name_2)
				result_1 = df.loc[((df['Stknm']== name_1)&(df['Date'].isin([date+'29',date+'30',date+'31']))),'Montmv']
				result_2 = df.loc[((df['Stknm']== name_2)&(df['Date'].isin([date+'29',date+'30',date+'31']))),'Montmv']
				#result_1 = df.loc[((df['Stknm']== name_1)&(df['Date']==re.compile(date))),'Montmv']
				#result_2 = df.loc[((df['Stknm']== name_2)&(df['Date']==re.compile(date))),'Montmv']
				#print(result_1)
				print(df.head(2))
				print(df.loc[((df['Stknm']== name_1)&(df['Date'].isin([date+'29',date+'30',date+'31']))),'Montmv'])
				if not result_1.empty:
					mvalue_1 = result_1.values[0]
					finished_mv += 1
					print(name_1+':'+mvalue_1)
				elif not result_2.empty:
					mvalue_2 = result_2.values[0]
					finished_mv += 1
					print(name_2+':'+mvalue_2)
				elif finished_mv >= 2:
					break
				else:
					print(mvalue_1+'###')
					continue