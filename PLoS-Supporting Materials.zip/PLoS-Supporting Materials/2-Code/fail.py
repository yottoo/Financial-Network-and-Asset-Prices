from urllib.request import urlopen
from urllib.request import Request
from urllib import parse
from bs4 import BeautifulSoup
import re
import pymysql.cursors
import requests
import time
import json
import codecs
from decimal import getcontext, Decimal 
import math

#数据库连接用
connection = pymysql.connect(
	host = 'localhost',
	user = 'root',
	password = 'java',
	db = 'funds_info',
	charset = 'utf8mb4'
	)

date = '2012/3/'
filename = '2012-1'
filepath = 'C:\\Users\\zhiha\\Desktop\\20171117\\'+filename+'.net'
n = 0

name_col = 0
stock_name = {}
stock_strength = {}
with codecs.open(filepath,'r','utf-8') as f:
	while True:
		line = f.readline()
		if not line:
			break
		n += 1
		if n==1:
			name_col = line.split(' ')[-1]
			#print(name_col)
		elif n <= int(name_col)+1:
			number = line.split(' ')[0]
			name = line.split(' ')[-1].strip()
			stock_name.update({number:name})
			stock_strength.update({number:0})
			#print(stock_strength)
			#print(stock_name)
		elif n > int(name_col)+2:
			cursor = connection.cursor()
			stock_1 = line.split(' ')[0]
			stock_2 = line.split(' ')[1]
			name_1 = stock_name.get(stock_1)
			name_2 = stock_name.get(stock_2)
			sql_mvalue1 = 'select Montmv from market_value where Stknm = '+name_1+' and Date like "%'+date+'%"'
			sql_mvalue2 = 'select Montmv from market_value where Stknm = '+name_2+' and Date like "%'+date+'%"'
			print(sql_mvalue1)	
			print(sql_mvalue2)
			cursor.execute(sql_mvalue1)
			mvalue_1 = cursor.fetchone()[0]
			cursor.execute(sql_mvalue2)
			mvalue_2 = cursor.fetchone()[0]

			sql = 'SELECT FdCd FROM top10_hold where FdCd in (select FdCd from top10_hold where StkNm ='+name_1+' and RepDt like "%'+date+'%") and StkNm = '+name_2+' and RepDt like "%'+date+'%"'
			#print(sql)

			cursor.execute(sql)
			rows = cursor.fetchall()
			#print(rows)
			strength = 0
			for row in rows:
				value_1 = ''
				value_2 = ''
				sql_fvalue1 = 'select MktV from top10_hold where FdCd ='+row[0]+' and StkNm ='+name_1+' and RepDt like "%'+date+'%"'
				#ln(MktV)
				sql_fvalue2 = 'select MktV from top10_hold where FdCd ='+row[0]+' and StkNm ='+name_2+' and RepDt like "%'+date+'%"'
				
				#print(sql_value1)
				#print(sql_value2)
				cursor.execute(sql_fvalue1)
				fvalue_1 = cursor.fetchone()[0]
				cursor.execute(sql_fvalue2)
				fvalue_2 = cursor.fetchone()[0]
			
				#print(value_1)
				#print(value_2)
				#strength += Decimal(float(value_1)*float(value_2)).quantize(Decimal('0.0000')) 
				strength += (float(fvalue_1)*float(fvalue_2))/(float(mvalue_1)*float(mvalue_2))
			print(stock_1+' '+stock_2+' '+str(strength))
			stock_strength[stock_1] = float(strength)+stock_strength[stock_1]
			stock_strength[stock_2] = float(strength)+stock_strength[stock_2]
		print(stock_strength)
				
