from urllib.request import urlopen
from urllib.request import Request
from urllib import parse
from bs4 import BeautifulSoup
import re
import pymysql.cursors
import requests
import time
import json
import codecs
from decimal import getcontext, Decimal 
import math
import csv
import pandas as pd
import sys



#def read_csv(mvfile_path):
#	df = pd.read_csv(mvfile_path,encoding='utf-8',header=0)
#	return df


def mv_value(num_1,num_2,date):
	print(num_1)
	print(num_2)
	value_1 = ''
	value_2 = ''
	count = 0
	for mvfile_num in range(1,6):
		mvfile_path = 'C:\\Users\\zhiha\\Desktop\\market_value\\'+str(mvfile_num)+'.csv'
		df = pd.read_csv(mvfile_path,encoding='utf-8',header=0)
		#print(df.head(5))
		#df.loc[((df['Stknm']== name_2)&(df['Date']==re.compile(date))),'Montmv']
		#&(df['Date']==re.compile(date))
		#findnum_1 = df.loc[((df['Stknm']== name_1)),'Stkcd']
		#findnum_2 = df.loc[((df['Stknm']== name_2)),'Stkcd']
		result_1 = df.loc[((df['Stkcd']== num_1)&(df['Date'].isin([date+'29',date+'30',date+'31']))),'Montmv']
		result_2 = df.loc[((df['Stkcd']== num_2)&(df['Date'].isin([date+'29',date+'30',date+'31']))),'Montmv']

		if not result_1.empty:
			value_1 = result_1.values[0]
			count += 1
			print(mvfile_path)
			print('1:'+str(value_1))

		if not result_2.empty:
			value_2 = result_2.values[0]
			count += 1
			print(mvfile_path)
			print('2:'+str(value_2))
		if count >= 2:
			break
	if value_1 == '' or value_2 == '':
		return 1
	else:
		return float(value_1)*float(value_2)




#数据库连接用
connection = pymysql.connect(
	host = 'localhost',
	user = 'root',
	password = 'java',
	db = 'funds_info',
	charset = 'utf8mb4'
	)





date = '2014/12/'
filename = '2014-4'
filepath = 'C:\\Users\\zhiha\\Desktop\\20171117\\'+filename+'.net'
n = 0

name_col = 0
stock_name = {}
stock_strength = {}
with codecs.open(filepath,'r','utf-8') as f:
	while True:
		line = f.readline()
		if not line:
			break
		n += 1
		if n==1:
			name_col = line.split(' ')[-1]
			#print(name_col)
		elif n <= int(name_col)+1:
			number = line.split(' ')[0]
			name = line.split(' ')[-1].strip()
			stock_name.update({number:name})
			stock_strength.update({number:0})
			#print(stock_strength)
			#print(stock_name)
		elif n > int(name_col)+2:
			
			wrong_stock_value = []
			stock_1 = line.split(' ')[0]
			stock_2 = line.split(' ')[1]
			name_1 = stock_name.get(stock_1)
			name_2 = stock_name.get(stock_2)

			print(name_1+'&'+name_2+':'+date)
			#numfile_path = 'C:\\Users\\zhiha\\Desktop\\top10_stock.csv'
			#df = pd.read_csv(numfile_path,encoding='utf-8',header=0)
			#num_1 = df.loc[((df['Stknm']== name_1.replace('"',''))),'Stkcd'].values[0]
			#num_2 = df.loc[((df['Stknm']== name_2.replace('"',''))),'Stkcd'].values[0]


			#total_value = mv_value(num_1,num_2,date)
			#print('市值积为：'+str(total_value))
			#if total_value == 1 :
			#	wrong_stock_value.append(str(num_1)+','+str(num_2))
			


			cursor = connection.cursor()
			sql = 'SELECT FdCd FROM top10_hold where FdCd in (select FdCd from top10_hold where StkNm ='+name_1+' and RepDt like "%'+date+'%") and StkNm = '+name_2+' and RepDt like "%'+date+'%"'
			#print(sql)

			cursor.execute(sql)
			rows = cursor.fetchall()
			#print(rows)
			strength = 0
			for row in rows:
				value_1 = ''
				value_2 = ''
				sql_fvalue1 = 'select MktV from top10_hold where FdCd ='+row[0]+' and StkNm ='+name_1+' and RepDt like "%'+date+'%"'
				#ln(MktV)
				sql_fvalue2 = 'select MktV from top10_hold where FdCd ='+row[0]+' and StkNm ='+name_2+' and RepDt like "%'+date+'%"'
				
				#print(sql_value1)
				#print(sql_value2)
				cursor.execute(sql_fvalue1)
				fvalue_1 = cursor.fetchone()[0]
				cursor.execute(sql_fvalue2)
				fvalue_2 = cursor.fetchone()[0]
			
				#print(value_1)
				#print(value_2)
				#strength += Decimal(float(value_1)*float(value_2)).quantize(Decimal('0.0000'))
				#if total_value == 1:
				#	continue
				#else: 
				strength += (float(fvalue_1)*float(fvalue_2))
			print(stock_1+' '+stock_2+' '+str(strength))
			stock_strength[stock_1] = float(strength)+stock_strength[stock_1]
			stock_strength[stock_2] = float(strength)+stock_strength[stock_2]
		print(stock_strength)
		print('----------------')

try:
	writepath = 'C:\\Users\\zhiha\\Desktop\\out_weighted_net\\'+filename+'.txt'
	for values in stock_strength.values():
		print(values)
		with open(writepath,'a') as w:
			w.write(str(values)+'\n')
except:
	print('fail')

print(wrong_stock_value)			
