from urllib.request import urlopen
from urllib.request import Request
from urllib import parse
from bs4 import BeautifulSoup
import re
import pymysql.cursors
import requests
import time
import json
import codecs
from decimal import getcontext, Decimal 
import math
import csv
import pandas as pd
import sys

mvfile_num = '2012-2'
file_path = 'C:\\Users\\zhiha\\Desktop\\weighted_net\\'+str(mvfile_num)+'.txt'

with codecs.open(file_path,'r','utf-8') as f:
	raw = str(f.readlines()).split(',')
	try:
		writepath = 'C:\\Users\\zhiha\\Desktop\\temple\\'+mvfile_num+'.txt'
		for r in raw:
			line = r.split(':')[-1]
			print(line)
			with open(writepath,'a') as w:
				w.write(str(line)+'\n')
	except:
		print('fail')


	# for r in raw:
	# 	print(r.split(':')[-1])
	# 	line = r.split(':')[-1]
	# 	try:
	# 		writepath = 'C:\\Users\\zhiha\\Desktop\\temple\\'+mvfile_num+'.txt'
	# 		for values in stock_strength.values():
	# 			print(values)
	# 			with open(writepath,'a') as w:
	# 				w.write(str(values)+'\n')
	# 	except:
	# 		print('fail')

	# for value in new_dict:
	# 	print(value)