
import pandas as pd
import numpy as np
import statsmodels.api as sm
import math

result = open('C:\\Users\\zhiha\\Desktop\\result_compare\\after-1.txt','a')
result.write('日期 节点数量 调整R方 D-W检验 常量 收盘价 波动率_指数加权移动平均() 总股季流通换手率 季收益率 市净率 ln月流通市值\n')
init_year = 17 
while(init_year < 18):
	for i in range(1,2):
		filename = ''
		if init_year < 10:
			filename = '200'+str(init_year)+'-'+str(i)
		elif init_year >=10:
			filename = '20'+str(init_year)+'-'+str(i)
		print(filename)
		data = pd.read_excel('C:\\Users\\zhiha\\Desktop\\after-1\\cal\\'+filename+'.xlsx')
		#('C:\\Users\\zhiha\\Desktop\\stock_compare\\before\\'+filename+'\\1 - 副本.xlsx')
		#('C:\\Users\\zhiha\\Desktop\\before-2\\cal_excel\\'+filename+'.xlsx')
		feature_col = ['收盘价','波动率_指数加权移动平均()','总股季流通换手率','季收益率','市净率']
		#'波动率_指数加权移动平均()','波动率_Garch()',流通股季换手率，总股季流通换手率
		X = data[feature_col]
		Y = data['点度中心性']
		ln = []

		for i in data['月流通市值(元)']: #月流通市值(元)
			if i > 0 : 
				ln.append(math.log(i/100000000))
			else:
				ln.append(i)
		X['ln月流通市值'] = ln

		Y.head()

		x = sm.add_constant(X)
		model = sm.OLS(Y,x)
		results = model.fit()

		result.write(filename.split('-')[0]+'///'+filename.split('-')[1]+' '+str(results.nobs)+' '+str(results.rsquared_adj)+' '+str(sm.stats.durbin_watson(results.resid.values))+'\n')
		pvalues = ''
		params = ''
		stats = ''
		for p in list(results.pvalues):
			pvalues = pvalues + str(p) + ' '
		for pa in list(results.params):
			params = params + str(pa) + ' '
		for st in list(results.tvalues):
			stats = stats + '('+str(st)+')' + ' '

		result.write(pvalues+'\n')
		result.write(params+'\n')
		result.write(stats+'\n')

		print('时间：'+filename)
		print('节点数量:')
		print(results.nobs)
		print('调整R方：')
		print(results.rsquared_adj)
		print('D-W检验：')
		print(sm.stats.durbin_watson(results.resid.values))
		print('F检验：')
		print(results.f_pvalue)
		print('T检验：')
		print(list(results.pvalues))
		print('系数：')
		print(list(results.params))
		print('t-统计量：')
		print(results.tvalues)
		print('-----------------------------------')
	init_year = init_year + 1


