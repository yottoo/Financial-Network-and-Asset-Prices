from urllib.request import urlopen
from urllib.request import Request
from urllib import parse
from bs4 import BeautifulSoup
import re
import pymysql.cursors
import requests
import time
import json
import codecs


#数据库连接用
connection = pymysql.connect(
	host = 'localhost',
	user = 'root',
	password = 'java',
	db = 'funds_info',
	charset = 'utf8mb4'
	)

filepath = 'C:\\Users\\zhiha\\Desktop\\quarter\\'
year = 17
while(year<18):
	for quarter in range(1,3):
		filename = ''
		name = ''
		if year < 10 :
			name = '200' + str(year) + '-' + str(quarter)
		elif year >= 10:
			name = '20' + str(year) + '-' + str(quarter)
		filename = filepath+name+'.net'
		with open(filename, "r", encoding="utf8") as this_file:
			#print(this_file)
			tag = 0
			for line in this_file.readlines():
				tag = tag + 1
				if tag == 1 :
					line_num = int(line.split(' ')[-1])
				elif tag <= line_num+1 :
					stock_name = (line.split('"')[-2])
					cursor = connection.cursor()
					sql = "select Stkcd from all_stock where Stknm = '"+stock_name+"'"
					print(sql)
					try:
						cursor.execute(sql)
						result = cursor.fetchone()
						for r in result:
							print(r)
							writepath = 'C:\\Users\\zhiha\\Desktop\\quarter\\stock-'+name+'.txt'
							with open(writepath,'a') as w:
								w.write(r+'\t')
					except:
						print('fail')

		print('-------------------------')
	year = year + 1