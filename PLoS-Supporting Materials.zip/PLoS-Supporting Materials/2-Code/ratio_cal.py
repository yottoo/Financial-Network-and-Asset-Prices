import csv
import pandas as pd
import codecs


txt_path = 'C:\\Users\\zhiha\\Desktop\\2017-3-contain_stock.txt'
hold_path = 'C:\\Users\\zhiha\\Desktop\\2017-3.csv'
market_path = 'C:\\Users\\zhiha\\Desktop\\2017-3-market_value.csv'

fail_stock = []

#df = pd.read_csv(path,encoding='gbk',header=0)
with codecs.open(txt_path,'r','utf-8') as stock_txt:
	while True:
		stock_num = stock_txt.readline()
		#print(stock_num)
		if not stock_num:
			break
		market_file = pd.read_csv(market_path,encoding='gbk',header=0)
		#print(type(market_file['Stkcd']))
		#print(type(stock_num))
		#print(df_m['Stkcd'])
		market = market_file.loc[market_file['Stkcd'] == int(stock_num),'Montmv']
		name = market_file.loc[market_file['Stkcd'] == int(stock_num),'Stknm']
		#print(market)
		if not market.empty:
			market_value = market.values[0]
			name = name.values[0]
			#print('流通市值：'+str(market_value))
			hold_file = pd.read_csv(hold_path,encoding='gbk',header=0)
			hold = hold_file.loc[(hold_file['Stkcd']==int(stock_num)),'MktV']
			#print(hold)
			if not hold.empty:
				hold_value = 0.0
				for each_hold in hold.values:
					hold_value += float(each_hold)
			#print('基金持股市值：'+str(hold_value))
			ratio = float(hold_value)/float(market_value)
			#print('持股市值占总市值比例：'+str(ratio))
			#print(stock_num.strip()+' '+name+' '+str(market_value)+' '+str(hold_value)+' '+str(ratio))
			#print('-----------------------')
		else:
			stock_name = hold_file.loc[(hold_file['Stkcd']==int(stock_num)),'Stknm'].values[0]
			fail_stock.append(str(stock_num).replace('\r\n','')+' '+str(stock_name))
print('无市值股票为：'+str(len(fail_stock)))
for k in fail_stock:
	print(k)
#print(fail_stock)



# result_1 = df.groupby('StkCd')
# for name in result_1:
# 	print(str(name[0]))

# csv_file = csv.reader(open(path,encoding='utf-8'))
# print(csv_file)
# n = 0
# for row in csv_file:
# 	print(row[2])
# 	n+=1
# 	if n >= 10:
# 		break