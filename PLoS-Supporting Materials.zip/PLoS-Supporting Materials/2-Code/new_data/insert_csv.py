import pandas as pd
import codecs
import re
import numpy as np

def get_order():
	order_file = []
	with codecs.open(order_file_path,'r','gbk') as f :
		lines = f.readlines()
		n = 0
		for line in lines:
			if n == 0:
				d = line.split(' ')[1].strip()
				this_date = d.split('/')[0]+'-'+d.split('/')[1]
				#print(this_date)
			if not line=='\r\n' and not n == 0:
				order_file.append(line.replace('\r','')+' '+this_date)
			n += 1
	#print(order_file)
	return order_file

def get_cen(ser_cen):
	total_cen = []
	for cen in ser_cen:
		cen_file = []
		with codecs.open(cen,'r','gbk') as f:
			lines = f.readlines()
			n = 0
			for line in lines:
				if not n == 0:
					line_value = line.strip()
					cen_file.append(line_value)
					#print(line.strip())
				n+=1
			total_cen.append(cen_file)
	#print(total_cen)
	return total_cen

def get_str(file):
	strength = []
	with codecs.open(file,'r','gbk') as f:
		lines = f.readlines()
		for line in lines:
			line_value = line.strip()
			strength.append(line_value)
	#print(strength)
	return strength

			
def get_base_attr():
	base_attr = []
	order = get_order()
	total_cen = get_cen(ser_cen)
	strength = get_str(str_file)
	n=0
	for value in order:
		line = str(value)+' '+str(total_cen[0][n])+' '+str(total_cen[1][n])+' '+str(total_cen[2][n])+' '+str(strength[n])
		print(line)
		base_attr.append(line)
		# print('order:'+str(value))
		# print('cen_be:'+str(total_cen[0][n]))
		# print('cen_cl:'+str(total_cen[1][n]))
		# print('cen_de:'+str(total_cen[2][n]))
		# print('strength:'+str(strength[n]))
		n+=1
	return base_attr

def get_market_value():
	total = []
	order = get_order()

	year = date.split('/')[0]
	market_path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\stock_market_performance\\'+year+'.csv'
	f = pd.read_csv(market_path,encoding='gbk',header=0)

	for each in order:
		stock_num = float(each.split(' ')[1])
		
		#收盘价、成交量、流通股季换手率\流通股平均日换手率\流通股\季收益率\流通市值加权平均市场季资本收益率\季无风险收益率、市盈率\每股收益\净资产收益率\日期
		attr_list = ['Clpr','Trdvol','QtrTrdTurnR','AvgDtrdTurnR','Trdshr','Qtrret','Qarettmv','Qtrrfret','PE','EPS','ROE','Date']
		#market_value = file.loc[(file['Stkcd']==stock_num) & (file['Date'].isin([date+'29',date+'30',date+'31'])),attr_list].values[0]
		market_value = f.loc[(f['Stkcd']==stock_num)&(f.Date.str.contains(date)),attr_list]
		if not market_value.empty:
			market_value = market_value.values[0]
		else:
			market_value = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]
		#print(market_value)
		print('市场绩效表现:'+str(stock_num)+':'+str(list(market_value)))
		total.append(list(market_value))
		#print(type(stock_num))
	print('---------------------------------')
	return total

def get_volatility():
	volatility = []
	order = get_order()
	year = date.split('/')[0]
	month = date.split('/')[1]
	month_order = int(int(month)/3)
	v_path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\volatility\\'+year+'-'+str(month_order)+'-v.csv'
	#print(v_path)
	v = pd.read_csv(v_path,encoding='gbk',header=0)
	for each in order:
		stock_num = float(each.split(' ')[1])
		#print(stock_num)
		v_value = v.loc[(v['Stkcd']==stock_num)&(v.Date.str.contains(date)),'Ewma']
		if not v_value.empty:
			v_value = v_value.values[0]
		else:
			v_value = 0.0
		volatility.append(v_value)
		print('波动率:'+str(stock_num)+':'+str(v_value))
		#print(float(v_value))
	print('--------------------------------------')
	return volatility
		
def get_turn_value():
	total_tvalue = []
	order = get_order()
	for each in order:
		t_value = 0.0
		stock_num = float(each.split(' ')[1])
		for n in range(1,5):
			path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\stock_market_value\\'+str(n)+'.csv'
			t = pd.read_csv(path,encoding='gbk',header=0)
			t_line = t.loc[(t['Stkcd']==stock_num)&(t.Date.str.contains(date)),'Montmv']
			if not t_line.empty:
				t_value = float(t_line.values[0])
				print('流通市值:'+str(stock_num)+':'+str(t_value))
				break
		total_tvalue.append(t_value)
	print('--------------------------------------------------------')
	return total_tvalue


def get_other_attr():
	other_attr = []
	turn_set = get_turn_value()
	market_value_set = get_market_value()
	volatility_set = get_volatility()
	n = 0
	for market in market_value_set:
		#print(market)
		line = str(market).replace('[','').replace(']','').replace(',','')+' '+str(turn_set[n])+' '+str(volatility_set[n])
		#print(line)
		other_attr.append(line)
		#print(type(line))
		# print('流通市值：'+str(turn_set[n]))
		# print('波动率：'+str(volatility_set[n]))
		n+=1
	print(other_attr)
	print('---------------------------')
	return other_attr

file = '2017-3'
date = '2017/9/'

order_file_path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\eachyear_stock_set\\'+file+'-StockSet.txt'
be_file = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\节点中心性\\'+file+'\\be.vec'
cl_file = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\节点中心性\\'+file+'\\cl.vec'
de_file = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\节点中心性\\'+file+'\\de.vec'
ser_cen = [be_file,cl_file,de_file]

str_file = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\节点中心性\\'+file+'\\str.txt'
w_path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\节点中心性\\NetStock_Attr_same.txt'

base_attr = get_base_attr()
other_attr = get_other_attr()
with open(w_path,'a+') as w:
	n = 0
	row_name = '序列 股票代码 股票名称 构建网络截点 中介中心性 接近中心性 点度中心性 节点强度 收盘价 成交量 流通股季换手率 流通股平均日换手率 流通股 季收益率 流通市值加权平均市场季资本收益率 季无风险收益率 市盈率 每股收益 净资产收益率 日期 流动资产 波动率' 
	#w.write(row_name+'\n')
	for value in base_attr:
		line = value+' '+other_attr[n]
		print(line)
		w.write(line+'\n')
		n+=1

#get_market_value()
#get_volatility()
#get_base_attr()




