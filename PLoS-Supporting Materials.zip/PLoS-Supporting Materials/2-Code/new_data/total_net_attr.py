import pandas as pd
import codecs
import re
import numpy as np

#date = '2009/12/'
ori_path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\top10_hold_utf-8.csv'
w_path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\stock_num.txt'
s_path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\market_value.txt'
file = pd.read_csv(ori_path,encoding='utf-8',header=0)

def stock_num():
	year = 6
	while year<=17:
		comp_year = ''
		if year <10:
			comp_year = '200'+str(year)
		elif year >=10:
			comp_year = '20'+str(year)
		with open(w_path,'a+') as w:
			for i in range(1,5):
				date = str(comp_year)+'/'+str(3*i)+'/'
				print(date)
				num = file.loc[(file['RepDt'].isin([date+'29',date+'30',date+'31']))].groupby('StkCd').size()
				print(len(num))
				w.write(str(len(num))+'\n')
		year+=1

def total_market_value():
	year = 6
	while year<=17:
		comp_year = ''
		if year <10:
			comp_year = '200'+str(year)
		elif year >=10:
			comp_year = '20'+str(year)
		with open(s_path,'a+') as w:
			for i in range(1,5):
				date = str(comp_year)+'/'+str(3*i)+'/'
				print(date)
				market_value = file.loc[(file['RepDt'].isin([date+'29',date+'30',date+'31'])),'MktV']
				total = 0.0
				for each in market_value.values:
					total += float(each)
				print(total)
				w.write(str(total)+'\n')
		year+=1

total_market_value()


