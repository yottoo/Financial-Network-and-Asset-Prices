import pandas as pd
import codecs
import re
import numpy as np


date = '2009/12/'
filename = '2009-4'
ori_path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\top10_hold_utf-8.csv'
w_path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\stock_network\\'+filename+'.net'
file = pd.read_csv(ori_path,encoding='utf-8',header=0)

def year_stock_set():
	thisyear_stock = []
	

	#stock_set = file.groupby('StkCd').count()
	stock_set = file.loc[(file['RepDt'].isin([date+'29',date+'30',date+'31']))].groupby('StkCd').count()
	num = file.loc[(file['RepDt'].isin([date+'29',date+'30',date+'31']))].groupby('StkCd').size()
	path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\stock_network\\eachyear_stock_set\\'+filename+'-stock.txt'

	with open(path,'a+') as w:	
		w.write(str(len(num))+' '+date+'\n')
		for i in stock_set.index:	
			content = str(i)+' '+str(file.loc[(file['StkCd']==i) & (file['RepDt'].isin([date+'29',date+'30',date+'31'])),'LstkNm'].values[0])
			w.write(content+'\n')
			print(content)
		#print(len(num))

	for i in stock_set.index:
		thisyear_stock.append(i)
	#print(len(num))
	print(thisyear_stock)
	print('----------------------------')
	return thisyear_stock

# def stock_name(stock_set):
# 	name_set = {}
# 	for stock_num in stock_set:
# 		name = file.loc[(file['StkCd']==stock_num)&(file['RepDt'].isin([date+'29',date+'30',date+'31'])),'LstkNm']
# 		if not name.empty:
# 			stock_name = name.values[0]
# 			name_set.update({stock_num:stock_name})
# 	return name_set


def rel_fund(stock_set):
	wrong = 0
	stock_fund = {}
	for stock in stock_set:
		fund_set = []	
		fund = file.loc[(file['StkCd']== stock) & (file['RepDt'].isin([date+'29',date+'30',date+'31'])),'FdCd']
		if not fund.empty:
			for fund_num in fund.values:
				fund_set.append(fund_num)
		else:
			wrong+=1
		stock_fund.update({stock:fund_set})
	print(stock_fund)
	print('股票所属基金报错次数：'+str(wrong))
	print('--------------------------------')
	return stock_fund

def rel_stock(rel_fund):
	stock_stock = {}
	wrong = 0
	edge_count = 0
	for key in rel_fund.keys():
		rel_stock_set = {}
		for fund in rel_fund.get(key):
			stock = file.loc[(file['FdCd']==fund) & (file['RepDt'].isin([date+'29',date+'30',date+'31'])),'StkCd']
			if not stock.empty:
				for stock_num in stock.values:
					if stock_num in stock_stock:
						continue
					elif stock_num == key: 
						continue
					elif np.isnan(stock_num):
						continue
					elif stock_num in rel_stock_set:
						count = int(rel_stock_set.get(stock_num))+1
						rel_stock_set.update({stock_num:count})
					else:
						edge_count+=1
						count = 1
						rel_stock_set.update({stock_num:count})
			else:
				wrong+=1
		stock_stock.update({key:rel_stock_set})
	#stock_stock.update({'edg':edge_count})
	#print('总连边数：'+str(edge_count))
	print(stock_stock)
	print('寻找连边股票时错误次数：'+str(wrong))
	print('---------------------------------')
	return stock_stock

#--------------程序运行处--------------------
stock_set = year_stock_set()
#name_set = stock_name(stock_set)
result = rel_stock(rel_fund(stock_set))
stock_order = {}
#为股票节点设置序列
n = 1
for stock in result.keys():
	name = file.loc[(file['StkCd']==stock)&(file['RepDt'].isin([date+'29',date+'30',date+'31'])),'LstkNm'].values[0]
	value = {n:name}
	stock_order.update({stock:value})
	n+=1

with open(w_path,'a+') as w:
	#写入节点信息
	stock_count = len(result)
	print('节点数量：'+str(stock_count))
	w.write('*Vertices'+' '+str(stock_count)+'\n')
	for stock in stock_order.keys():
		order = list(stock_order.get(stock).keys())[0]
		name = list(stock_order.get(stock).values())[0]
		print(str(order)+' '+str(name))
		w.write(str(order)+' "'+str(name)+'"\n')

	#写入连边信息
	w.write('*Edges'+'\n')
	for key_stock in result.keys():
		key_end_tag = len(result.keys())
		key_order = list(stock_order.get(key_stock).keys())[0]
		relstock_set = result.get(key_stock)
		#print(edge_count)
		for relstock_num in relstock_set.keys():
			rel_end_tag = len(relstock_set.keys())
			strength = relstock_set.get(relstock_num)
			rel_order = list(stock_order.get(relstock_num))[0]
			#print(str(key_stock)+' '+str(relstock_num)+' '+str(strength)+'\n')

			w.write(str(key_order)+' '+str(rel_order)+' '+str(strength)+'\n')
			print(str(key_order)+' '+str(rel_order)+' '+str(strength))
		#print('--------------------------------------------')







#rel_fund(year_stock_set())

