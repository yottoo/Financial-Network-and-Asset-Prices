import pandas as pd
import codecs
import re
import numpy as np



#file = '2006-4'
#date = '2006/9/'

def get_stock_num(file):
	stock_set_file = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\eachyear_stock_set\\'+file+'-StockSet.txt'
	stock_set = {}
	with codecs.open(stock_set_file,'r','gbk') as f:
		lines =f.readlines()
		print(lines)
		n = 0
		for line in list(lines):
			n+=1
			if not n == 1:
				if not line == '\r\n':
					#print(line)
					stock_order = line.split(' ')[0]
					stock_num = line.split(' ')[1]
					#print(stock_num)
					#print(str(n)+' '+line)
					stock_set.update({stock_order:stock_num})
		print(file)
	print(stock_set)
	print('-------------------------------------')
	return stock_set
	#return stock_set

file = '2007-4'
date = '2007/12/'

stock_net_path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\stock_network\\'+file+'.net'
market_value_path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\top10_hold_utf-8.csv'
write_path = 'C:\\Users\\zhiha\\Desktop\\2018-3-9sum\\节点中心性\\'+file+'\\'+'str.txt'

#打开基金持股市值文件
hold = pd.read_csv(market_value_path,encoding='utf-8',header=0)

#得到股票序列与股票代码之间的对应关系
stock_set = get_stock_num(file)

#初始化各个股票节点的节点强度
result = {}
for key in stock_set.keys():
	result.update({key:0.0})
print(result)

#读取股票网络文件，基于连边信息得到连边权重值
with codecs.open(stock_net_path,'r','gbk') as f:
	lines = f.readlines()
	n = 0
	for line in lines:
		n+=1
		if n == 1:
			flag = line.split(' ')[-1].replace('\r\n','')
			print(flag)
		elif n > int(flag)+2:
			#print(line.replace('\r\n',''))
			stock_1_order = line.split(' ')[0]
			stock_2_order = line.split(' ')[1]
			stock_1_num = float(stock_set.get(stock_1_order))
			stock_2_num = float(stock_set.get(stock_2_order))
			#print(type(stock_1_num))
			#print(stock_1_num)
			#print(stock_2_num)
			fund_1 = hold.loc[(hold['StkCd']==stock_1_num) & (hold['RepDt'].isin([date+'29',date+'30',date+'31'])),'FdCd']
			if not fund_1.empty:
				fund_12 = hold.loc[((hold['StkCd']==stock_2_num) & (hold['FdCd'].isin(fund_1)) & (hold['RepDt'].isin([date+'29',date+'30',date+'31']))),'FdCd']
				if not fund_12.empty:
					#for fund in fund_12:
					for fund in fund_12:
						#print(fund)
						#基于每个共同基金，计算相关股票之间的连边权重
						rel_stock_set = hold.loc[(hold['FdCd']==fund)&(hold['RepDt'].isin([date+'29',date+'30',date+'31'])),['StkCd','MktV']]
						out_12 = 0.0
						for rel_stock in rel_stock_set.values:
							if rel_stock[0]==stock_1_num:
								value_1 = rel_stock[1]	
							elif rel_stock[0]==stock_2_num:
								value_2 = rel_stock[1]					
							else:				
								out_12 += float(rel_stock[1])
						# print('v2:'+str(value_2))
						# print('v1:'+str(value_1))
						# print('out_12:'+str(out_12))
						out_1 = out_12 + value_2
						out_2 = out_12 + value_1
						mul = value_1*value_2
						other = (out_1+out_2)/(out_1*out_2)
						strength = mul*other
						s_1 = result.get(stock_1_order)
						s_2 = result.get(stock_2_order)
						# print(str(stock_1_order)+':'+str(s_1))
						# print(str(stock_2_order)+':'+str(s_2))
						# print(strength)
						result.update({stock_1_order:(s_1+strength)})
						result.update({stock_2_order:(s_2+strength)})
						#print(result)
						# print('mul:'+str(mul))
						# print('other:'+str(other))
						# print('strength:'+str(strength))			
						#print(rel_stock_set.values)
					#print('--------------------')
with open(write_path,'a+') as w:
	for value in result.values():
		w.write(str(value)+'\n')
		print(value)

# num = 7
# while num <= 17:
# 	if num < 10:
# 		file_name = '200'+str(num)
# 	elif num >= 10:
# 		file_name = '20'+str(num)
# 	for i in range(1,5):
# 		file = file_name+'-'+str(i)
# 		get_stock_num(file)
# 	num+=1